package com.capgemini.parnextgen.Model;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
